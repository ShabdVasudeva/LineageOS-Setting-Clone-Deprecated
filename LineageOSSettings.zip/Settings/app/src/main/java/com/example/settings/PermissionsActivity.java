package com.example.settings;

import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import com.google.android.material.appbar.MaterialToolbar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;
import com.example.settings.databinding.ActivityPermissionsBinding;
public class PermissionsActivity extends AppCompatActivity {
    private ActivityPermissionsBinding bind;
    private PermModel permModel;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        bind = ActivityPermissionsBinding.inflate(getLayoutInflater());
        setContentView(bind.getRoot());
        setSupportActionBar(bind.toolbar3);
        bind.toolbar3.setNavigationOnClickListener(v ->{
            onBackPressed();
        });
        permModel = new ViewModelProvider(this).get(PermModel.class);
        setT(bind.text1,bind.subtext1,bind.icon1,permModel.title[0],permModel.subtitle[0],permModel.images[0]);
        setT(bind.text2,bind.subtext2,bind.icon2,permModel.title[1],permModel.subtitle[1],permModel.images[1]);
        setT(bind.text3,bind.subtext3,bind.icon3,permModel.title[2],permModel.subtitle[2],permModel.images[2]);
        setT(bind.text4,bind.subtext4,bind.icon4,permModel.title[3],permModel.subtitle[3],permModel.images[3]);
        clicked(new Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS),bind.modify);
        clicked(new Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS),bind.usage);
        clicked(new Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION),bind.files);
        clicked(new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES),bind.unknown);
    }
    public void setT(TextView title,TextView subtitle,ImageView img,String str1,String str2,int id){
        title.setText(str1);
        subtitle.setText(str2);
        img.setImageResource(id);
    }
    public void clicked(Intent in,LinearLayout ll){
        ll.setOnClickListener(v ->{
           try{
               startActivity(in);
           }catch(Exception u){
               Toast.makeText(getApplicationContext(),"sorry this setting is not available for your device",Toast.LENGTH_SHORT).show();
           }
        });
    }
}
