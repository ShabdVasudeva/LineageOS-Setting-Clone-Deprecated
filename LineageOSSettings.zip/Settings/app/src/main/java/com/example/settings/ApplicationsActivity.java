package com.example.settings;

import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;
import com.example.settings.databinding.ActivityApplicationsBinding;

public class ApplicationsActivity extends AppCompatActivity {
    private ActivityApplicationsBinding ap;
    private Model mViewModel;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ap = ActivityApplicationsBinding.inflate(getLayoutInflater());
        setContentView(ap.getRoot());
        setSupportActionBar(ap.toolbar);
        ap.toolbar.setNavigationOnClickListener(v ->{
            onBackPressed();
        });
        mViewModel = new ViewModelProvider(this).get(Model.class);
        setVal(ap.text1,ap.subtext1,mViewModel.titles[0],mViewModel.subtitles[0]);
        setVal(ap.text2,ap.subtext2,mViewModel.titles[1],mViewModel.subtitles[1]);
        setVal(ap.text3,ap.subtext3,mViewModel.titles[2],mViewModel.subtitles[2]);
        setVal(ap.text4,ap.subtext4,mViewModel.titles[3],mViewModel.subtitles[3]);
        setVal(ap.text5,ap.subtext5,mViewModel.titles[4],mViewModel.subtitles[4]);
        instant(new Intent(Settings.ACTION_APPLICATION_SETTINGS),ap.allapps);
        instant(new Intent(Settings.ACTION_MANAGE_DEFAULT_APPS_SETTINGS),ap.defaultapps);
        instant(new Intent(Settings.ACTION_HOME_SETTINGS),ap.quickswitch);
        instant(new Intent(Settings.ACTION_VOICE_INPUT_SETTINGS),ap.assistant);
        ap.permissions.setOnClickListener(v ->{
                startActivity(new Intent(this,PermissionsActivity.class));
        });
    }
    public void setVal(TextView title,TextView subtitle,String str1,String str2) {
    	title.setText(str1);
        subtitle.setText(str2);
    }
    public void instant(Intent ug,LinearLayout fg){
        fg.setOnClickListener(v ->{
            try{
                startActivity(ug);
            }catch(Exception io){
                Toast.makeText(getApplicationContext(),"An error occured",Toast.LENGTH_SHORT).show();
            }
        });
    }
}
