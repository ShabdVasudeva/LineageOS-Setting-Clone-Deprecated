package com.example.settings;
import androidx.lifecycle.ViewModel;

public class PermModel extends ViewModel {
    String[]title={
        "Modify system settings",
        "Usage access",
        "Files access",
        "Unknown sources"
    };
    String[]subtitle={
        "Manage permission for modify system settings",
        "Manage usage access permission",
        "Manage permissions for files access",
        "Allow to install app from 3rd party sources"
    };
    int[]images={
        R.drawable.modify,
        R.drawable.usage,
        R.drawable.files,
        R.drawable.unknown
    };
}
