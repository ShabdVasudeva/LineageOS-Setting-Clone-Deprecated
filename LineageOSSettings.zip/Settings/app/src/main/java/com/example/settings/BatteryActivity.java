package com.example.settings;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.ResolveInfo;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.BatteryManager;
import android.os.Bundle;
import androidx.core.content.ContextCompat;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import com.google.android.material.progressindicator.LinearProgressIndicator;
import android.os.Build;
import android.provider.Settings;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.divider.MaterialDivider;
import com.google.android.material.materialswitch.MaterialSwitch;
import com.google.android.material.color.DynamicColors;
import com.google.android.material.color.utilities.DynamicColor;
import java.util.Date;
import com.example.settings.databinding.ActivityBatteryBinding;

public class BatteryActivity extends AppCompatActivity {
    public ActivityBatteryBinding battery;
    private BroadcastReceiver mBatInfoReceiver =
            new BroadcastReceiver() {
                @Override
                public void onReceive(Context ctxt, Intent intent) {
                    try {
                        int level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
                        int scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, -1);
                        int batteryPct = level * 100 / (int) scale;
                        String technology =
                                intent.getExtras().getString(BatteryManager.EXTRA_TECHNOLOGY);
                        int health = intent.getIntExtra(BatteryManager.EXTRA_HEALTH, 0);
                        int temperature = intent.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, -1);
                        battery.percentage.setText(String.valueOf(batteryPct));
                        battery.progressbar.setProgressCompat(batteryPct, true);
                        battery.tech.setText(technology);
                        battery.temp.setText(temperature / 10.0 + "°c");
                        if (health == BatteryManager.BATTERY_HEALTH_COLD) {
                            battery.hlth.setText("Cold");
                        } else if (health == BatteryManager.BATTERY_HEALTH_GOOD) {
                            battery.hlth.setText("Good");
                        } else if (health == BatteryManager.BATTERY_HEALTH_DEAD) {
                            battery.hlth.setText("Dead");
                        } else if (health == BatteryManager.BATTERY_HEALTH_OVER_VOLTAGE) {
                            battery.hlth.setText("Over Voltage");
                        } else if (health == BatteryManager.BATTERY_HEALTH_OVERHEAT) {
                            battery.hlth.setText("Over Heating");
                        } else {
                            battery.hlth.setText("Unknown");
                        }
                    } catch (Exception ig) {
                        Toast.makeText(
                                getApplicationContext(), "an error occured", Toast.LENGTH_SHORT);
                    }
                }
            };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        try {
            super.onCreate(savedInstanceState);
            battery = ActivityBatteryBinding.inflate(getLayoutInflater());
            setContentView(battery.getRoot());
            setSupportActionBar(battery.toolbar);
            showBatteryEstimation(getApplicationContext());
            battery.toolbar.setNavigationOnClickListener(
                    v -> {
                        onBackPressed();
                    });
            this.registerReceiver(
                    this.mBatInfoReceiver, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
            IntentFilter ifilter = new IntentFilter(Intent.ACTION_BATTERY_CHANGED);
            Intent batteryStatus = this.registerReceiver(null, ifilter);
            Intent batteryTechnology = this.registerReceiver(null, ifilter);
            int status =
                    batteryStatus != null
                            ? batteryStatus.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
                            : -1;
            boolean isCharging =
                    status == BatteryManager.BATTERY_STATUS_CHARGING
                            || status == BatteryManager.BATTERY_STATUS_FULL;
            if (isCharging) {
                battery.advice.setText("Charging rapidly • please wait untill full charge");
            }
            battery.saver.setOnClickListener(
                    v -> {
                        startActivity(new Intent(this, BatterySaver.class));
                    });
            int currentNightMode =
                    getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK;
            switch (currentNightMode) {
                case Configuration.UI_MODE_NIGHT_NO:
                    battery.progressbar.setIndicatorColor(Color.BLACK);
                    battery.toolbar.setNavigationIconTint(Color.BLACK);
                    break;
                case Configuration.UI_MODE_NIGHT_YES:
                    battery.toolbar.setNavigationIconTint(Color.WHITE);
                    battery.info.setColorFilter(
                            ContextCompat.getColor(getApplicationContext(), android.R.color.white),
                            android.graphics.PorterDuff.Mode.SRC_IN);
            }
            battery.usage.setOnClickListener(
                    v -> {
                        Intent a = new Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS);
                        startActivity(a);
                    });
            String hello = String.valueOf(battery.advice.getText());
        } catch (Exception fo) {
            Toast.makeText(getApplicationContext(), "an error occured", Toast.LENGTH_SHORT).show();
        }
    }

    public void showBatteryEstimation(Context context) {
        IntentFilter filter = new IntentFilter(Intent.ACTION_BATTERY_CHANGED);
        Intent batteryStatus = context.registerReceiver(null, filter);

        int level = batteryStatus.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
        int scale = batteryStatus.getIntExtra(BatteryManager.EXTRA_SCALE, -1);

        int batteryPercent = (int) ((level / (float) scale) * 100);
        int remainingTimeHours = batteryPercent;

        String message = "Estimated remaining time: " + remainingTimeHours + " hours";
        battery.advice.setText(message);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        this.battery = null;
    }
}
