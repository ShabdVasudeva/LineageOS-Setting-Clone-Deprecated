package com.example.settings;

import android.app.WallpaperManager;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import com.example.settings.databinding.WallpapersUtilBinding;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import java.io.IOException;

public class WallpapersUtil extends AppCompatActivity {
    private WallpapersUtilBinding binding;
    private static final int PICK_IMAGE_REQUEST = 1;

    private int colorToString(String color) {
        return Color.parseColor(color);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = WallpapersUtilBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        setSupportActionBar(binding.toolbar);
        binding.toolbar.setNavigationOnClickListener(
                v -> {
                    onBackPressed();
                });
        binding.textie.setOnClickListener(
                v -> {
                    Toast.makeText(
                                    getApplicationContext(),
                                    "These wallpapers ae brought to you by Waze wallpapers channel",
                                    Toast.LENGTH_LONG)
                            .show();
                });
        binding.gradient1.setOnClickListener(
                v -> {
                    int a, b;
                    a = colorToString("#73F565");
                    b = colorToString("#299EA8");
                    setWallpaperWithGradientColors(a, b);
                });
        binding.gradient2.setOnClickListener(
                v -> {
                    int a, b;
                    a = colorToString("#E1CBE0");
                    b = colorToString("#6F5697");
                    setWallpaperWithGradientColors(a, b);
                });
        binding.gradient3.setOnClickListener(
                v -> {
                    int a, b;
                    a = colorToString("#1928FD");
                    b = colorToString("#299EA8");
                    setWallpaperWithGradientColors(a, b);
                });
        binding.gradient4.setOnClickListener(
                v -> {
                    int a, b;
                    a = colorToString("#CA7AE4");
                    b = colorToString("#7006F5");
                    setWallpaperWithGradientColors(a, b);
                });
        binding.gradient5.setOnClickListener(
                v -> {
                    int a, b;
                    a = colorToString("#AEEB9F");
                    b = colorToString("#1E8B88");
                    setWallpaperWithGradientColors(a, b);
                });
        binding.gradient6.setOnClickListener(
                v -> {
                    int a, b;
                    a = colorToString("#F4D0BC");
                    b = colorToString("#2A3ABE");
                    setWallpaperWithGradientColors(a, b);
                });
        binding.gradient7.setOnClickListener(
                v -> {
                    int a, b;
                    a = colorToString("#0D5C88");
                    b = colorToString("#F0B073");
                    setWallpaperWithGradientColors(a, b);
                });
        binding.gallery.setOnClickListener(
                v -> {
                    openImagePicker();
                });
        binding.wall1.setOnClickListener(v ->{
            final WallpaperManager wallpaperManager = WallpaperManager.getInstance(getApplicationContext());
                try {
                	wallpaperManager.setResource(R.drawable.wall1);
                } catch(Exception err) {
                	Toast.makeText(getApplicationContext(),"an error occured",Toast.LENGTH_LONG).show();
                }
        });
        binding.wall2.setOnClickListener(v ->{
            final WallpaperManager wallpaperManager = WallpaperManager.getInstance(getApplicationContext());
                try {
                	wallpaperManager.setResource(R.drawable.wall2);
                } catch(Exception err) {
                	Toast.makeText(getApplicationContext(),"an error occured",Toast.LENGTH_LONG).show();
                }
        });
       binding.wall3.setOnClickListener(v ->{
            final WallpaperManager wallpaperManager = WallpaperManager.getInstance(getApplicationContext());
                try {
                	wallpaperManager.setResource(R.drawable.wall3);
                } catch(Exception err) {
                	Toast.makeText(getApplicationContext(),"an error occured",Toast.LENGTH_LONG).show();
                }
        });
        binding.wall4.setOnClickListener(v ->{
            final WallpaperManager wallpaperManager = WallpaperManager.getInstance(getApplicationContext());
                try {
                	wallpaperManager.setResource(R.drawable.wall4);
                } catch(Exception err) {
                	Toast.makeText(getApplicationContext(),"an error occured",Toast.LENGTH_LONG).show();
                }
        });
        binding.wall5.setOnClickListener(v ->{
            final WallpaperManager wallpaperManager = WallpaperManager.getInstance(getApplicationContext());
                try {
                	wallpaperManager.setResource(R.drawable.wall5);
                } catch(Exception err) {
                	Toast.makeText(getApplicationContext(),"an error occured",Toast.LENGTH_LONG).show();
                }
        });
       binding.wall6.setOnClickListener(v ->{
            final WallpaperManager wallpaperManager = WallpaperManager.getInstance(getApplicationContext());
                try {
                	wallpaperManager.setResource(R.drawable.wall6);
                } catch(Exception err) {
                	Toast.makeText(getApplicationContext(),"an error occured",Toast.LENGTH_LONG).show();
                }
        });
        binding.wall7.setOnClickListener(v ->{
            final WallpaperManager wallpaperManager = WallpaperManager.getInstance(getApplicationContext());
                try {
                	wallpaperManager.setResource(R.drawable.wall7);
                } catch(Exception err) {
                	Toast.makeText(getApplicationContext(),"an error occured",Toast.LENGTH_LONG).show();
                }
        });
    }

    private Bitmap resizeBitmap(Bitmap bitmap, int targetWidth, int targetHeight) {
        return Bitmap.createScaledBitmap(bitmap, targetWidth, targetHeight, true);
    }

    private void setWallpaperWithGradientColors(int startColor, int endColor) {
        GradientDrawable gradientDrawable =
                new GradientDrawable(
                        GradientDrawable.Orientation.TOP_BOTTOM, new int[] {startColor, endColor});
        Bitmap bitmap = Bitmap.createBitmap(100, 100, Bitmap.Config.ARGB_8888);
        gradientDrawable.setBounds(0, 0, 100, 100);
        gradientDrawable.draw(new Canvas(bitmap));
        int screenWidth = Resources.getSystem().getDisplayMetrics().widthPixels;
        int screenHeight = Resources.getSystem().getDisplayMetrics().heightPixels;
        Bitmap resizedBitmap = resizeBitmap(bitmap, screenWidth, screenHeight);
        WallpaperManager wallpaperManager = WallpaperManager.getInstance(this);
        MaterialAlertDialogBuilder builder = new MaterialAlertDialogBuilder(this);
        builder.setTitle("Set wallpaper as")
                .setNegativeButton(
                        "Lockscreen",
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                try {
                                    wallpaperManager.setBitmap(
                                            resizedBitmap, null, true, WallpaperManager.FLAG_LOCK);
                                } catch (Exception e) {
                                    e.printStackTrace();
                                }
                            }
                        })
                .setPositiveButton(
                        "Homescreen",
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                try {
                                    wallpaperManager.setBitmap(
                                            resizedBitmap,
                                            null,
                                            true,
                                            WallpaperManager.FLAG_SYSTEM);
                                } catch (Exception e) {
                                    e.printStackTrace();
                                }
                            }
                        })
                .setNeutralButton(
                        "Both",
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                try {
                                    wallpaperManager.setBitmap(resizedBitmap);
                                } catch (Exception e) {
                                    e.printStackTrace();
                                }
                            }
                        })
                .show();
    }

    private void openImagePicker() {
        Intent pickImageIntent =
                new Intent(
                        Intent.ACTION_PICK,
                        android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        startActivityForResult(pickImageIntent, PICK_IMAGE_REQUEST);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == PICK_IMAGE_REQUEST && resultCode == RESULT_OK && data != null) {
            Uri selectedImageUri = data.getData();
            MaterialAlertDialogBuilder builder = new MaterialAlertDialogBuilder(this);
            builder.setTitle("Set wallpaper as")
                    .setNegativeButton(
                            "Lockscreen",
                            new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    setWallpaperLock(selectedImageUri);
                                }
                            })
                    .setPositiveButton(
                            "Homescreen",
                            new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    setWallpaper(selectedImageUri);
                                }
                            })
                    .setNeutralButton(
                            "Both",
                            new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    setWallpaperBoth(selectedImageUri);
                                }
                            })
                    .show();
        }
    }

    private void setWallpaper(Uri imageUri) {
        try {
            WallpaperManager wallpaperManager = WallpaperManager.getInstance(this);
            wallpaperManager.setStream(
                    getContentResolver().openInputStream(imageUri),
                    null,
                    false,
                    WallpaperManager.FLAG_SYSTEM);
            Toast.makeText(this, "Wallpaper set successfully", Toast.LENGTH_SHORT).show();
        } catch (IOException e) {
            e.printStackTrace();
            Toast.makeText(this, "Failed to set wallpaper", Toast.LENGTH_SHORT).show();
        }
    }

    private void setWallpaperLock(Uri imageUri) {
        try {
            WallpaperManager wallpaperManager = WallpaperManager.getInstance(this);
            wallpaperManager.setStream(
                    getContentResolver().openInputStream(imageUri),
                    null,
                    false,
                    WallpaperManager.FLAG_LOCK);
            Toast.makeText(this, "Wallpaper set successfully", Toast.LENGTH_SHORT).show();
        } catch (IOException e) {
            e.printStackTrace();
            Toast.makeText(this, "Failed to set wallpaper", Toast.LENGTH_SHORT).show();
        }
    }
    private void setWallpaperBoth(Uri imageUri) {
        try {
            WallpaperManager wallpaperManager = WallpaperManager.getInstance(this);
            wallpaperManager.setStream(getContentResolver().openInputStream(imageUri));
            Toast.makeText(this, "Wallpaper set successfully", Toast.LENGTH_SHORT).show();
        } catch (IOException e) {
            e.printStackTrace();
            Toast.makeText(this, "Failed to set wallpaper", Toast.LENGTH_SHORT).show();
        }
    }

    private void success() {
        Toast.makeText(this, "Wallpaper set successfully", Toast.LENGTH_SHORT).show();
    }
}
