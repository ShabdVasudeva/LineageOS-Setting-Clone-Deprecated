package com.example.settings;
import androidx.lifecycle.ViewModel;

public class Model extends ViewModel {
    String[]titles={
        "All applications",
        "Default applications",
        "Quick switch",
        "Assistant",
        "Permission manager"
    };
    String[]subtitles={
        "Manage all applications",
        "Manage default applications",
        "Change your default home application",
        "Hey google and other assistant settings",
        "Manage applications permissions"
    };
}
