package com.example.settings;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.util.DisplayMetrics;
import android.view.GestureDetector;
import android.view.View;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.example.settings.databinding.ActivityAboutBinding;
public class AboutActivity extends AppCompatActivity {
    private ActivityAboutBinding abt;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        abt = ActivityAboutBinding.inflate(getLayoutInflater());
        setContentView(abt.getRoot());
        setSupportActionBar(abt.toolbar);
        abt.toolbar.setNavigationOnClickListener(v ->{
            onBackPressed();
        });
        abt.device.setText(Build.MODEL.toLowerCase());
        abt.andro.setText(Build.VERSION.RELEASE);
        abt.secure.setText(Build.VERSION.SECURITY_PATCH);
        abt.base.setText(Build.getRadioVersion());
        String version = System.getProperty("os.version");
        abt.kernel.setText(version);
        String hard = android.os.Build.HARDWARE;
        abt.hard.setText(hard);
        DisplayMetrics displayMetrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        int width = displayMetrics.widthPixels;
        int height = displayMetrics.heightPixels;
        abt.size.setText(width + "x" + height);
        abt.more.setOnClickListener(v ->{
            startActivity(new Intent(Settings.ACTION_DEVICE_INFO_SETTINGS));
        });
        abt.android.setOnClickListener(v ->{
                Toast.makeText(getApplicationContext(),"our team is working for easter egg please be patiant",Toast.LENGTH_SHORT).show();
        });
    }
}
