package com.example.settings;
import androidx.lifecycle.ViewModel;

public class ModelMain extends ViewModel {
    String[] title = {
        "Network & internet",
        "Connected devices",
        "Apps",
        "Extensions",
        "Notifications",
        "Battery",
        "Storage",
        "Sound & vibrations",
        "Display",
        "Wallpaper & styles",
        "Accessibility",
        "Security",
        "Privacy",
        "Location",
        "Printing service",
        "Accounts",
        "Digital Wellbeing & parental controls",
        "System",
        "About phone",
        "Tips & support"
    };
    String[] subtitle = {
        "Mobile, Wi-Fi, hotspot",
        "Bluetooth, pairing",
        "Manage, default apps",
        "Extend your device",
        "Notifocation history, conversations",
        "get your battery performace stats",
        "Storage stats, usage",
        "Volume, haptics, Do Not Disturb",
        "Dark theme, font, brightness",
        "Colors, wallpapers, solids",
        "Display, interaction, audio",
        "Screen lock, Find My Device, app security",
        "Permission, account activity, personal data",
        "Location, apps using gps",
        "Default printer service",
        "Synced accounts",
        "Screen time, app timers, bedtime schedules",
        "Languages, time, backup",
        "about your phone",
        "Help articles & about us"
    };
    int[] imgid = {
        R.drawable.wifi_icon,
        R.drawable.bluetooth_pair,
        R.drawable.apps,
        R.drawable.extensions,
        R.drawable.notifications,
        R.drawable.battery_icon,
        R.drawable.storage,
        R.drawable.sound,
        R.drawable.display,
        R.drawable.styles,
        R.drawable.accessibility,
        R.drawable.security,
        R.drawable.privacy,
        R.drawable.location,
        R.drawable.print,
        R.drawable.account,
        R.drawable.digital,
        R.drawable.system,
        R.drawable.about,
        R.drawable.tips
    };
}
