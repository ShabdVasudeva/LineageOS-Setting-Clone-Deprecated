package com.example.settings;

import android.content.ComponentName;
import android.content.Intent;
import android.provider.Settings;
import com.example.settings.StylesModel;
import android.Manifest;
import android.content.pm.PackageManager;
import android.app.WallpaperManager;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.ParcelFileDescriptor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.widget.ImageView;
import android.os.Bundle;
import android.Manifest.permission;
import android.annotation.SuppressLint;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.core.app.ActivityCompat;
import androidx.lifecycle.ViewModelProvider;
import com.example.settings.databinding.ActivityStylesBinding;

public class StylesActivity extends AppCompatActivity {
    private ActivityStylesBinding binding;
    private StylesModel model;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityStylesBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        setSupportActionBar(binding.toolbar);
        
        binding.toolbar.setNavigationOnClickListener(
                v -> {
                    onBackPressed();
                });
        binding.homeset.setOnClickListener(
                v -> {
                    Intent ig = new Intent();
                    ig.setClassName(
                            "app.lawnchair", "app.lawnchair.ui.preferences.PreferenceActivity");
                    try {
                        startActivity(ig);
                    } catch (Exception io) {
                        Toast.makeText(
                                getApplicationContext(),
                                "please install our lawnchair fork to perform this task",
                                Toast.LENGTH_LONG);
                    }
                });
        binding.palette.setOnClickListener(
                v -> {
                    Intent intent = new Intent();
                    intent.setComponent(
                            new ComponentName(
                                    "dev.kdrag0n.dyntheme",
                                    "dev.kdrag0n.dyntheme.ui.main.MainActivity"));
                    try {
                        startActivity(intent);
                    } catch (Exception e) {
                        Toast.makeText(
                                        this,
                                        "Please install Repainter app first",
                                        Toast.LENGTH_SHORT)
                                .show();
                    }
                });
        binding.textbutton.setOnClickListener(v ->{
            startActivity(new Intent(this,WallpapersUtil.class));
        });
        binding.daydream.setOnClickListener(v ->{
            try{
                startActivity(new Intent(Settings.ACTION_DREAM_SETTINGS));
            }catch(Exception ios){
                Toast.makeText(getApplicationContext(),"your device don't support this setting",Toast.LENGTH_SHORT).show();
            }
        });
        model = new ViewModelProvider(this).get(StylesModel.class);
        binding.icon1.setImageResource(model.image);
        binding.text1.setText(model.text);
        binding.subtext1.setText(model.subtitle);
        try {
            model.getLockScreenWallpaper()
                    .observe(
                            this,
                            lockScreenWallpaper -> {
                                binding.lock.setBackgroundDrawable(lockScreenWallpaper);
                            });

            model.getHomeScreenWallpaper()
                    .observe(
                            this,
                            homeScreenWallpaper -> {
                                binding.home.setBackgroundDrawable(homeScreenWallpaper);
                            });
        } catch (Exception sh) {
            Toast.makeText(
                            getApplicationContext(),
                            "give feedback to the developer about this error please",
                            Toast.LENGTH_SHORT)
                    .show();
        }
        model.retrieveLockScreenWallpaper(this);
        model.retrieveHomeScreenWallpaper(this);
    }
}
