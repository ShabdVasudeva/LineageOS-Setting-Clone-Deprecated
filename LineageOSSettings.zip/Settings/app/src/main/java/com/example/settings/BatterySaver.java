package com.example.settings;

import android.content.ComponentName;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.os.PowerManager;
import android.provider.Settings;
import android.widget.CompoundButton;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.materialswitch.MaterialSwitch;
import com.google.android.material.materialswitch.MaterialSwitch;
import com.google.android.material.transition.MaterialArcMotion;
import com.example.settings.databinding.BatterySaverBinding;

public class BatterySaver extends AppCompatActivity {
    private BatterySaverBinding saver;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        try {
            super.onCreate(savedInstanceState);
            saver = BatterySaverBinding.inflate(getLayoutInflater());
            setContentView(saver.getRoot());
            setSupportActionBar(saver.toolbar2);
            saver.toolbar2.setNavigationOnClickListener(
                    v -> {
                        onBackPressed();
                    });
            SharedPreferences sharedPreferences = getSharedPreferences("save", MODE_PRIVATE);
            saver.switch2.setChecked(sharedPreferences.getBoolean("value", false));
            saver.switch2.setOnCheckedChangeListener(
                    new CompoundButton.OnCheckedChangeListener() {
                        @Override
                        public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                            Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                            intent.putExtra("SWITCH_STATE", isChecked);
                            if (isChecked) {
                                SharedPreferences.Editor editor =
                                        getSharedPreferences("save", MODE_PRIVATE).edit();
                                editor.putBoolean("value", true);
                                editor.apply();
                                saver.switch2.setChecked(true);
                                Intent power = new Intent();
                                power.setComponent(
                                        new ComponentName(
                                                "com.android.settings",
                                                "com.android.settings.Settings$BatterySaverSettingsActivity"));
                                startActivityForResult(power, 0);
                            } else {
                                SharedPreferences.Editor editor =
                                        getSharedPreferences("save", MODE_PRIVATE).edit();
                                editor.putBoolean("value", false);
                                editor.apply();
                                saver.switch2.setChecked(false);
                                Intent power = new Intent();
                                power.setComponent(
                                        new ComponentName(
                                                "com.android.settings",
                                                "com.android.settings.Settings$BatterySaverSettingsActivity"));
                                startActivityForResult(power, 1);
                            }
                        }
                    });
            int currentNightMode =
                    getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK;
            switch (currentNightMode) {
                case Configuration.UI_MODE_NIGHT_NO:
                    saver.toolbar2.setNavigationIconTint(Color.BLACK);
                    break;
                case Configuration.UI_MODE_NIGHT_YES:
                    saver.toolbar2.setNavigationIconTint(Color.WHITE);
                    saver.info.setColorFilter(
                            ContextCompat.getColor(getApplicationContext(), android.R.color.white),
                            android.graphics.PorterDuff.Mode.SRC_IN);
            }
        } catch (Exception io) {
            Toast.makeText(getApplicationContext(), "an error occured", Toast.LENGTH_SHORT).show();
        }
    }
}
